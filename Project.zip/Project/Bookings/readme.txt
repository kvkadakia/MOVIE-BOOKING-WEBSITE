reserve seats will redirect to seats.php

after confirmseats is done Payment.html opens

after submitting Payment.html the user is redirected to seats.php where he can confirmseats

a session variable is to be set on the Payment page and only if that session is active 
the user can confirm his seat